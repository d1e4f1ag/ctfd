# CTFd Rank for A Single Category

Add a page of ranks for a single category.
![Pic](img.png)
